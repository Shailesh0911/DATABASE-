drop table 
productsell

drop table producthistory

create table productsales
(
p_sid int,
product_id int foreign key References product(p_id),
qtysales numeric(10)
)   
select * from product
select * from productsales

insert into product values(1,'Laptop',25000,80),(2,'Desktop',17500,70),(3,'tv',5000,70)
insert into productsales values(1,1,10),(2,2,5),(3,1,5),(4,1,5)

create proc sp_idarrangeonemployee
as
@starting number numeric(10)

begin
select * from product where p_id = 1
end

execute sp_idarrangeonemployee
