
select * from [State 1]
select * from [OLE DB Destination country]
Foreign 

CREATE TABLE [State 11] (

    [State_Id] int identity(1,1) Primary Key,
    [State_Name] nvarchar(255),
    [Country_ID] int Foreign Key (Country_ID) References [OLE DB Destination country]
)
drop table [State 11]
select * from [State 11]

select * from emp


create table sha_shailesh
(
	e_id int,	
	e_name varchar(20),	
	e_email	varchar (30),
	e_gender varchar(6),
	e_salary numeric(12),
	e_age int,
	e_city varchar(30),
	d_id int,
	e_year int

)
select * from sha_shailesh
update emp_shailesh set e_salary = 3000
where e_id = 1
select * from emp_shailesh
select * from sha_shailesh
