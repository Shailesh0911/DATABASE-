use [Shailesh.Rajput]

select * from emp_bkp
create proc sp_dyn1
@e_name varchar(30),
@e_id int
as 
begin
update emp_bkp
set e_name = @e_name
where e_id = @e_id

end

execute sp_dyn1 'Jaydeep1',10

alter proc sp_dyn1
@tbl_name varchar(max) = null
as
begin
		declare @sql nvarchar(max)
		declare @1st varchar(1) = left(@tbl_name,1)

set @sql =

'create table ' + @tbl_name + '(' +
@1st +'_id int,'+
@1st +'_name varchar(max)' + ')'

exec (@sql)

end

exec sp_dyn1 'shailesh'

select * from shailesh

alter proc sp_dyn2
@tbl_name varchar(max),
@col varchar(20), @coldatatype varchar(20),
@col1 varchar(20),@coldatatype1 varchar(30)
as
begin
declare @sql nvarchar(max)


set @sql =
'Create table ' + @tbl_name + '(' +
+@col +' ' + @coldatatype + ','
+@col1 + ' ' +@coldatatype1
+ ')'
--print  (@sql)
exec (@sql)
end
exec sp_dyn2 't1','name','varchar(20)','Mobile','Numeric(12)'

select * from t1




