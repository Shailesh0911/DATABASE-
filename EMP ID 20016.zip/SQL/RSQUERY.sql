USE AdventureWorks2014

select top 2 * from Sales.SalesOrderDetail
select top 2 * from Sales.SalesOrderHeaderSalesReason
Sales.SalesOrderHeader

FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID
FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID
AdventureWorks2014.Sales.SalesOrderDetail: FK_SalesOrderDetail_SalesOrderHeader_SalesOrderID2



select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
sum(soh.TotalDue) as [Sales Amount],pc.name as category from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
cross join Production.ProductCategory as pc
group by DATEPART(yyyy,soh.DueDate),st.[Group],pc.Name
order by [Calendar Year]

select * from sales.SalesTerritory
select * from sales.SalesOrderDetail
select * from sales.SalesOrderHeader
select * from HumanResources.Employee
select * from person.Address
FK_SalesOrderDetail_SpecialOfferProduct_SpecialOfferIDProductID
AdventureWorks2014.Sales.SalesOrderHeader: FK_SalesOrderHeader_Address_BillToAddressID

select distinct datepart(yyyy,duedate) as [Year] from sales.SalesOrderHeader

select concat(FirstName,LastName) as [Employee] from person.Person

select distinct datename(MONTH,duedate) as [month] from sales.SalesOrderHeader

select top 2* from Person.Person
select top 2* from sales.SalesOrderHeader
select top 2* from sales.SalesTerritory








select concat(FirstName,LastName) as [Employee],datepart(yyyy,soh.DueDate) as [Year],datename(MONTH,soh.duedate) as [month],sum(TotalDue) as [Sales Amount]
from sales.SalesOrderHeader as soh 
join sales.SalesTerritory as st on soh.TerritoryID = st.TerritoryID
join sales.SalesOrderDetail as sod on soh.SalesOrderID = sod.SalesOrderID
join production.ProductCostHistory as pod on sod.ProductID = pod.ProductID
join person.CountryRegion as pcr on st.CountryRegionCode = pcr.CountryRegionCode
join Production.Product as pp on pod.ProductID = pp.ProductID
join production.ProductSubcategory as ps on ps.ProductSubcategoryID = pp.ProductSubcategoryID
join Production.ProductCategory as pc on pc.ProductCategoryID = ps.ProductCategoryID
join person.[Address] as pa on soh.BillToAddressID = pa.AddressID
join person.StateProvince as sp on pa.StateProvinceID = sp.StateProvinceID
join sales.SalesPerson as ssp on ssp.TerritoryID = st.TerritoryID
join HumanResources.Employee as hre on hre.BusinessEntityID = ssp.BusinessEntityID
join Person.Person as per on per.BusinessEntityID = hre.BusinessEntityID
group by concat(FirstName,LastName),datepart(yyyy,duedate),datename(MONTH,soh.duedate)
order by [Year]

select sum(TotalDue) as [Sales Amount] from sales.SalesOrderHeader


