
ALTER trigger productsell
on [dbo].[product]
for insert 
as
begin
		declare @pid int,@pname varchar(5),@pqty varchar(10)
		select @pid = pid from inserted
		select @pname = pname from inserted
		select @pqty = pqty from inserted
		
	insert into productsell values('New Customer with id :' + cast(@pid as nvarchar(20)) + ' ' + @pname + ' and '  +
	cast(@pqty as nvarchar(20)) + 'is added as ' + cast(getdate() as nvarchar(20)))
	print 'alter insert  trigger fired'
end


select * from product
select * from productsell


