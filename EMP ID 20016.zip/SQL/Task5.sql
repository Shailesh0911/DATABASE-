USE [Shailesh.Rajput]

select * from depatment
select * from employee

--question  
-- question 4
SELECT e_name,e_dob,(DATENAME(dw,e_dob)+','+CAST((DATEPART(day,e_dob)) AS VARCHAR)) 
  + '/' 
  + CAST(DATEname(MONTH,e_dob) AS VARCHAR) 
  + '/' 
  + CAST(DATEPART(yy, getdate()) AS VARCHAR) NEW_DOB
 
  from employee


select * from emp
 
 select concat(e_name, '  ' , e_email) as fullname from emp

