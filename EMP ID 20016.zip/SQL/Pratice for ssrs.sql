use [AdventureWorks2014]
 select top 2 * from Sales.SalesOrderHeader
 select top 2 * from Sales.SalesTerritory
 select top 2 * from Sales.SalesOrderDetail

 select distinct  datepart(yyyy,duedate) as [Calenderyear],st.[Group] as [salesTerritory],
 soh.TotalDue
 from sales.SalesOrderHeader as soh
 join sales.SalesTerritory as st on soh.TerritoryID = st.TerritoryID
 join sales.SalesOrderDetail as sod on soh.SalesOrderID = sod.SalesOrderID 
 join Production.ProductCostHistory as pch on sod.ProductID = pch.ProductID
 group by datepart(yyyy,DueDate),st.[Group],soh.TotalDue
 order by [Calenderyear]
 
SELECT DATEPART(YYYY, soh.DueDate) AS [calendar year], st.[Group] AS [Sales Territory Group], cr.Name AS [Sales Territory Country], cr.Name AS [Sales Territory Region], SUM(soh.TotalDue) AS [Sales Amount]
FROM     Sales.SalesOrderHeader AS soh 
INNER JOin       
Sales.SalesTerritory AS st ON soh.TerritoryID = st.TerritoryID
INNER JOIN		
Sales.SalesOrderDetail AS sod ON sod.SalesOrderID = sod.SalesOrderID 
INNER JOIN
Production.ProductCostHistory AS pch ON sod.ProductID = pch.ProductID
INNER JOIN
Person.CountryRegion AS cr ON st.CountryRegionCode = cr.CountryRegionCode
GROUP BY DATEPART(YYYY, soh.DueDate), st.[Group], cr.Name
ORDER BY [calendar year]
 