alter trigger quantity on
product
for delete
as 
begin
	declare @pid int,@pname varchar(30)
	select @pid = pid from deleted
	select @pname = pname from deleted
	 
	insert into demo values(1,concat('customer id delete :' , @pid , 'and name :' , @pname , 'is deleted at' ))
print 'After delete trigger fried....'
end

select * from product
select * from productsell
select * from demo

delete from demo where id=1
delete from product where pid=5
delete from productsell where psid=5

