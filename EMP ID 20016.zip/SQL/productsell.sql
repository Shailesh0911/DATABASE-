create trigger product
on database
for create_table, alter_table, drop_table, rename
as
begin
	print 'you are create, alter, rename or drop table'
end


create trigger productsell
on database
for drop_table
as
begin
	print 'table can''drop'
	print 1/0
end

select * from product
delete from product where pid=3

select * from productsell
delete from productsell where psid=3

drop table productsell
