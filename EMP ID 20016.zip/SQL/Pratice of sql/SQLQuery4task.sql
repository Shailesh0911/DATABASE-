select * into [Shailesh.Rajput.dbo.employee2] from [Shailesh.Rajput].dbo.employee where 1 = 2

select * from [Shailesh.Rajput.dbo.employee2] --task 1

--task 2
create table product
(
	pid int primary key,
	pname varchar(5),
	pqty varchar(10)
)
create table productsell
(
	psid int,
	pid int foreign key references product(pid),
	pqty varchar(10)
)
insert into product values(1,'apple',5)
insert into product values(2,'mango',6)
insert into product values(3,'grapes',3)

insert into productsell values(1,1,5)
insert into productsell values(2,2,6)
insert into productsell values(3,3,3)

select * from product

create PROCEDURE 
(
declare @psid varchar(20)

)
as
	set nocount on
		begin tran
			begin try
				update dbo.product
				set pqty = 1
				where pid= @psid
				end try

    begin catch
    rollback transaction 
    throw
    end catch





