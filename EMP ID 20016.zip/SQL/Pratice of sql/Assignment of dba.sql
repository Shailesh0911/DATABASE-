create table shaileshemp
(
id int primary key identity(1,1),
name varchar(20) not null,
gender varchar(10),
salary numeric(5) check(salary > 10000),
email varchar(100) unique,
e_state varchar(100) default('Gujarat')
)

select * from shaileshemp


insert into shaileshemp values('shailesh','Male',15000,'sha@gmail.com','Gujarat')

delete from shaileshemp where id = 2

insert into shaileshemp(name,gender,salary,email) values('vraj','Male',15000,'vraj@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('poonam','Male',15000,'poo@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('priyam','Male',15000,'priy@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('priya','Female',17000,'priya@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('Vishu','Male',15000,'vishu@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('Ganesh','Male',20000,'Ganesh@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('Jaydeep','Male',25000,'jay@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('Ridhi','Female',30000,'Ridhi@gmail.com')
insert into shaileshemp(name,gender,salary,email) values('Parth','Male',18000,'parth@gmail.com')



select name,salary from shaileshemp where salary = 15000
select * from shaileshemp where salary = 15000 -- use for same salary

WITH Result as -- to find 5th highest salary
(
SELECT *,dense_rank() OVER (ORDER BY salary Desc) as DenseRank
FROM shaileshemp
)
SELECT top 1 name, salary
FROM Result
where DenseRank = 5 

SELECT TOP 1 SALARY  -- second way to find highest salary
FROM (  
      SELECT DISTINCT TOP 5 SALARY  
      FROM shaileshemp 
      ORDER BY SALARY DESC  
      ) RESULT  
ORDER BY SALARY

select top 1 salary
from(select distinct top 5 salary
from shaileshemp order by salary desc) result
order by salary

               
select * from shaileshemp

CREATE TABLE [dbo].[emp](
	[e_id] [int] IDENTITY(1,1) NOT NULL,
	[e_name] [nvarchar](50) NULL,
	[e_email] [nvarchar](50) NULL,
	[e_gender] [nvarchar](10) NULL,
	[e_salary] [int] NULL,
	[e_age] [int] NULL,
	[e_city] [nvarchar](20) NULL,
	[d_id] [int] NULL,
	[e_year] [int] NULL
)
set identity_insert emp on
INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1, N'aminesh', N'aminesh@gmail.com', N'MALE', 345, 23, N'gandhinagar', 1, 2005)
INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (4, N'anil', N'anil@gmail.com', N'MALE', 345, 51, N'vadali', 4, 2007)
INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (5, N'raman', N'raman@gmail.com', N'MALE', 99, 72, N'vadali', 4, 2005)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (9, N'kumud', N'kumari@gmail.com', N'FEMALE', 340, 21, N'baroda', 4, 2005)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (10, N'jigisha', N'jigisha@gmail.com', N'FEMALE', 88, 23, N'baroda', 4, 2007)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1029, N'asha', N'asas', N'male', 165, 25, NULL, 1, 2020)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1035, N'aminesh MA', N'aminesh@gmail.com', N'MALE', 345, 23, N'gandhinagar', 1, 2005)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1037, N'aminesh', N'aminesh@gmail.com', N'female', 88, 23, N'gandhinagar', NULL, 2005)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1039, N'aminesh MA', N'aminesh@gmail.com', N'MALE', 99, 23, N'gandhinagar', NULL, 2005)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1040, N'anil', N'anil@gmail.com', N'MALE', 345, 51, N'vadali', NULL, 2007)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1041, N'asd', N'asas', N'male', 165, 25, NULL, NULL, 2020)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1042, N'jigisha', N'jigisha@gmail.com', N'FEMALE', 850, 23, N'baroda', NULL, 2007)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1043, N'kumari', N'kumari@gmail.com', N'FEMALE', 340, 21, N'baroda', NULL, 2005)

INSERT [dbo].[emp] ([e_id], [e_name], [e_email], [e_gender], [e_salary], [e_age], [e_city], [d_id], [e_year]) VALUES (1045, N'raman', N'raman@gmail.com', N'MALE', 525, 72, N'vadali', NULL, 2005)

select * from emp

select e_name,d_id from emp where d_id in (select d_id from emp group by d_id having count(*)>2)



