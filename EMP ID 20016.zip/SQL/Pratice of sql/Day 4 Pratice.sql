declare @tbl as table
(
	id int
)
 insert into @tbl values(1) -- we have run create variable and declare it then create and insert both can run

 select * from @tbl

 --begin try
 --end try
 --begin catch
 --end catch
 begin try
	--select 10/0 result
	select 10/5 result
	end try
	begin catch
			select ERROR_MESSAGE() as [Bhai divide by zero hot ha kabhi]
	end catch

-- alter view
alter view [dbo].[VM_emp] 
as 
select * from emp_bkp where e_salary > 11000

select * from VM_emp


-- Store procedure A stored procedure is a set of Structured Query Language
--(SQL) statements with an assigned name, which are stored in a relational database management system
--(RDBMS) as a group, so it can be reused and shared by multiple programs.

--create procedure <sp_name>
--parameter optionally
as
begin
end

execute sp_emp -- its complusary to execute the sp..

create proc sp_emp
as
begin
select * from emp_bkp
end

execute 

create proc sp_employee
as
begin
select * from emp_bkp
end

execute sp_employee

-- alter sp
alter proc sp_emp
as 
begin
	select e_name,e_state,e_salary from emp_bkp where e_state = 'gujarat' and e_salary > 14000
end

execute sp_emp

select * from emp_bkp

create proc sp_empGenderWise
@gender varchar(10)
as
begin
	select * from employee where e_gender = @gender
	end

	execute sp_empGenderWise @gender = 'Male' 
	execute sp_empGenderWise 'female'

	set identity_insert employee on
	insert into employee(e_id,e_name,e_mail,e_salary,e_dob,e_mob,e_state,department_id,e_city) values(12,'cvb','cvb@gmail.com',16000,'05/03/2001',7408178888,'Gujarat',3,'Surat')

	select * from employee

alter proc sp_empGenderWise
@gender varchar(20) = null
as
begin
	if @gender is null
	begin
		select * from employee
	end
	else
	begin
		select * from employee where e_gender = @gender or e_gender is null

	end
end
exec sp_empGenderWise 'Male'
exec sp_empGenderWise 'Female'
exec sp_empGenderWise 'null'

alter proc sp_empGenderWise
@gender varchar(20) = null
as
begin
	select * from employee where e_gender = @gender or @gender = null
end
--exec sp_helptext 'sp_empGenderWise'

exec sp_empGenderWise @gender='Male' 
exec sp_empGenderWise 'Female'
exec sp_empGenderWise 

SELECT * FROM employee

create proc sp_getempdata
@gender varchar(20) = null,
@city VARCHAR(30) = null
as
begin
	SELECT * from employee where e_city = @city and e_gender = @gender
end

exec sp_getempdata 'Male','Abc'
exec sp_getempdata 'abc','Male'
exec sp_getempdata 'Female','ahmedabad'
exec sp_getempdata @city = 'abc',@gender = 'Male'

--Insert Sp procdure

							