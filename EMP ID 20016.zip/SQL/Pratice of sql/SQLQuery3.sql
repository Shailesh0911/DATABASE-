
--Advanced function : null, Coalesce, exists, Cast, Convert

select * from employee

select e_name,e_gender,ISNULL(e_city,'abc') city from employee

update employee set e_city ='abc' where e_city is null


select coalesce('a','b','c','d','e') -- it will only provide one word

select coalesce(null,'b','c','d','e')

select coalesce('','b','c','d','e')

select *,coalesce(e_city,'Vadadore') city from employee

select *,coalesce(e_city,'abc') from employee

select top 5 * from sys.databases order by create_date desc -- to see database in desc order 


create database demo11
drop database demo11
select * from sys.tables -- to see table in system

create table demo11
(
date varchar(20)
)
insert into demo11 values('2022/05/10'),('2021/06/06'),('31/12/1992')

select * FROM demo11

select *,year(date) from demo11

update demo11
set date = '2022/05/10'
where date = '31/12/2022'
 
--alter table demo11
--alter column date datetime

-- cast: <column name> as  <datatype>
select *,cast(date as datetime) from demo11
select *,cast(date as varchar(20)) from demo11

--convert:(<datatype>,<column_name>)
select *,CONVERT(datetime,date) from demo11
select *,CONVERT(varchar (20),date),convert (varchar(6),date) from demo11

select *, len(convert(varchar (07),date)) from demo11

select *, datalength(convert(varchar (07),date)) from demo11

select *,datalength(convert(varchar(5),date)) from demo11 --we can display our length
 select len('abc')from employee
 select datalength('abc'),datalength('abccc')

 select * from emp_bkp

select distinct e_name,e_salary from emp_bkp



select * from employee

select e_city,sum(e_salary) from employee 
group by e_city

select distinct e_city,e_salary from employee

select distinct e_gender,e_city,e_salary from employee
 
 select  e_gender,e_city,e_salary,e_name from employee
 group by e_gender,e_city,e_salary,e_name

 select e_gender,e_city,e_salary,count(*) a from employee
 group by e_gender,e_city,e_salary having count(*) > 1

 -- creating table
 */*CREATE TABLE Multiplctable(c1 int ,c2 int ,c3 int,c4 int,c5 int,c6 int,c7 int,c8 int,c9 int ,c10 int)

DECLARE @Loopcon  int;--LOOP CONTROLL
Set @Loopcon=1;

WHILE(@Loopcon<=10)
    BEGIN;

            INSERT INTO Multiplctable 
            VALUES(@Loopcon*1,@Loopcon*2,@Loopcon*3,@Loopcon*4,@Loopcon*5,@Loopcon*6,
            @Loopcon*7,@Loopcon*8,@Loopcon*9,@Loopcon*10);

            SET @Loopcon=@Loopcon+1;
  END;
  SELECT M.c1 [1],M.c2 [2],M.c3 [3],M.c4 [4],M.c5 [5],M.c6 [6],M.c7 [7],M.c8 [8],M.c9 [9],M.c10 [10]
  FROM Multiplctable M */


 select *,e_city city from employee
where  e_city is null	

select *,e_city c from employee
 city order by e_city

select *,e_city city from employee order by e_city

select *,e_city city,e_gender gender from employee order by e_city


select * from employee

Create table demo3
(
id int ,
name varchar(20)
)
ALTER TABLE demo2
ADD PRIMARY KEY (ID);

ALTER TABLE demo2
ADD CONSTRAINT PK_Person PRIMARY KEY (id);

insert into demo1 values(1,'abc')


create 

drop table demo1
drop table demo2

select e_name,e_gender,e_salary,count(*) a from employee
group by e_name,e_gender,e_salary

Create table emp1
(
id int ,
name varchar(20),
gender varchar(10)
)
select * from emp1

Create table emp2
(
id int ,
name varchar(20),
gender varchar(10)
)

insert into emp1 values(1,'Shailesh','Male')
insert into emp1 values(2,'Jdbc','Male')
insert into emp1 values(3,'Ganesh','Male')

insert into emp2 values(1,'Shailesh','Male')
insert into emp2 values(2,'ulka','female')
insert into emp2 values(3,'Krisshna','Male')
insert into emp2 values(4,'ganesh','Male')

select name from emp1
union
select name from emp2

select name from emp1
union all
select name from emp2

select name from emp1
intersect
select name from emp2



select name from emp2
except
select name from emp1

-- variable
declare @name varchar(10) = 'hello'
print @name

declare @name varchar(12) 
set @name ='heloo'
print @name

declare @name varchar(12) 
select @name ='heloo'
print @name

declare @name varchar(10) ='RAJPUT'
set @name = 'Shailesh'
print @name

declare @name varchar(10) ='RAJPUT'
print @name
select @name = 'Shailesh'
print @name


declare @name varchar(10) ='RAJPUT'
print @name
set @name = 'Shailesh'
print @name

declare @name varchar(11) ='RAJPUT'
set @name = @name + 'Singh'
print @name

--case when then else end
select *,case when e_gender = 'Male' then 'M' else 'F' end newgender from employee
select *,case when e_salary >=15000 then 'high' when e_salary < 15000 and e_salary >=13000 then 'mid' else 'low' end newgender from employee
select * from emp_bkp
select * from employee

--iff
select * ,iif(e_gender='Male','M','F') newgender from employee

declare @val int =1
if @val < 2
	print 'neg'
else
	print 'pos'

	declare @val int = 10
	if @val < 0
	begin
		print 'neg'
	end
	else if
		@val > 0
		begin
			print 'pos'
		end
		else if
			@val is null
			begin
				print 'null'
			end
			else
			begin
				print 'Zero'
			end
--while <condition>
--begin

--<incr/decr>
--end

declare @c1 int = 10, @c2 int = 20
while @c1 <= @c2
begin
print @c1
	set @c1 += 1
end


declare @c1 int = 11, @c2 int = 20
while @c1 <= @c2
begin
print @c1

	continue
	break
	set @c1 +=5
	
end

declare @c1 int = 10, @c2 int = 20 --while loop with break and contniue
while @c1 < @c2
begin
set @c1 +=1
if @c1 = 15
	continue
	print @c1
end

declare @c1 int = 1, @c2 int = 10
while @c1 <= @c2
begin
	print @c1
	continue
	print @c2

set @c1 += 1
end


declare @c1 int = 1, @c2 int = 10
while @c1 <= @c2
begin
	print @c1
	break

set @c1 += 1
end

declare @c1 int = 1, @c2 int = 10
while @c1 <= @c2
begin
	print @c1
	break

set @c1 += 1
end

--cte 

--with <cte_name>
--as
--()
--use of cte

with def
as
(Select *,e_salary+100 sal from employee)
select * from def  where  sal = 11000
select * from employee

select e_name,max(e_salary) sa from employee group by e_name

declare @sal int --to found maximum salary in table
set @sal=(select max(e_salary) from employee )
select * from employee where e_salary = @sal

select max(e_salary) from employee -- is only for salary column
 --sub query

 select * from employee where e_salary =(select max(e_salary) sal from employee where e_gender = 'Male')
  select * from employee where e_salary =(select max(e_salary) sal from employee where e_gender = 'Female')

  select max(e_salary) from employee
  group by e_gender

  select * from employee where e_salary in
(
	select max(e_salary) from employee
	group by e_gender
)

select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'employee'

--view 
--create view <view_name>
--<query>

create view VM_emp
as
select * from dbo.employee

select * from VM_emp

--temporary tables : local temporary table, global temporary table
 select * from emp_bkp

 create table #employee
 (
	id int identity(1,1),
	e_name varchar(20)
 )
  select * from #employee

  
 create table ##employee
 (
	id int identity(1,1),
	e_name varchar(20)
 )

 select * into demo23 from
 (select e_name,e_mob from  employee )a
	






















