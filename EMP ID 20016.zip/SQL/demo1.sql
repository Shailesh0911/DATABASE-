
CREATE TRIGGER [dbo].[stock] on
[dbo].[product]
   after insert
AS 
BEGIN
		print 'you are create, alter, rename or drop table'
end

ALTER TRIGGER [dbo].[stock] on [dbo].[product]
   after insert
AS 
BEGIN
		print 'you are create, alter, rename or drop table'
end
ALTER trigger [dbo].[stock] on [dbo].[product]
for insert
as
begin
	declare @pid int,@pname varchar(20),@pqty varchar(10)
	select @pid = pid from inserted
	select @pname = pname from inserted
	select @pqty = pqty from inserted
	insert into productsell values('new customer with id : ' + cast(@pid as nvarchar(5)) + ' ' + @pname + ' and ' + 
	cast(@pqty as nvarchar(30)) + ' is added as ' + cast(getdate() as nvarchar(30)))

	PRINT 'AFTER INSERT trigger fired.'
end

select * from product
insert into product values(3,'apple',4)
select * from productsell