create table state(
s_id int primary key identity(1,1),
s_name varchar(50) not null
)
insert into state values('Gujarat')
insert into state values('Gujarat')
insert into state values('GOA')
insert into state values('Assam')
insert into state values('Punjab')


create table city(
c_id int primary key identity(1,1),
c_name varchar(50) not null,
state_id int Foreign key references state(s_id)
)

select * from state
select * from city

delete from state where s_id = 2	

insert into city values('Anand',1)
insert into city values('PANJI',3)
insert into city values('Dispur',4)
insert into city values('Amristar',5)

select * from state as s
join
city as c
on
s.s_id = c.state_id


SELECT * from state  as s
join city as c
on s.s_id = c.state_id

SELECT s.s_id, s.s_name, c.c_id, c.c_name, c.state_id
FROM     state AS s INNER JOIN
                  city AS c ON s.s_id =
                      (SELECT s_id                       FROM      state
                       WHERE   (s_name = 'Gujarat'))


select * 
from state as s
join city as c 
on s.s_id=
SELECT distinct (s_name)
FROM     state


SELECT distinct(c.c_name),s.s_name
FROM state  as s
join city as c
on c.state_id= s.s_id 
where s.s_name = 'gujarat'


SELECT distinct(c.c_name) , s.s_name
FROM     state AS s INNER JOIN
                  city AS c ON c.state_id = s.s_id
where (s.s_name = 'gujarat')  


SELECT distinct(c.c_name) 
FROM     state AS s INNER JOIN
                  city AS c ON c.state_id = s.s_id
where s.s_name in (@State)

select distinct(c_name) from city