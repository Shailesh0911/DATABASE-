USE [Shailesh.Rajput]
GO

/****** Object:  Trigger [dbo].[stock]    Script Date: 3/16/2022 11:48:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TRIGGER [dbo].[stock] on [dbo].[product]
   after insert
AS 
BEGIN
declare @pid int,@pname varchar(20),@pqty varchar(10)
	select @pid = pid from inserted
	select @pname = pname from inserted
	select @pqty = pqty from inserted
	insert into productsell values('new customer with id : ' + cast(@pid as nvarchar(5)) + ' ' + @pname + ' and ' + 
	cast(@pqty as nvarchar(30)) + ' is added as ' + cast(getdate() as nvarchar(30)))

		print 'you are create, alter, rename or drop table'
end




