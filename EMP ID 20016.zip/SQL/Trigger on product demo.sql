
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[history] on [dbo].[product1]
   AFTER INSERT
AS 
BEGIN
	declare @produtid int
	declare @produtName varchar(50)
	declare @produtDesc varchar(50)

	select @produtid = productList.productid from inserted productList
	select @produtName= productList.productName from inserted productList
	select @produtDesc = productList.productDesc from inserted productList

	insert into producthistory(productid,productName,productDesc) values (@produtid,@produtName,@produtDesc)


END
GO
select * from producthistory
insert into product1 values(1,'Apple','Desc')