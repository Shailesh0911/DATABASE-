--for sales table
SELECT DATEPART(YYYY, soh.DueDate) AS [Calendar Year], st.[Group] AS [Sales Territory Group],
SUM(soh.TotalDue) AS [Sales Amount], pc.Name  as category
FROM     Sales.SalesOrderHeader AS soh INNER JOIN
 Sales.SalesTerritory AS st ON soh.TerritoryID = st.TerritoryID 
 INNER JOIN
 Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
 INNER JOIN
 Production.ProductCostHistory AS pch ON sod.ProductID = pch.ProductID
 CROSS JOIN
 Production.ProductCategory AS pc
GROUP BY DATEPART(yyyy, soh.DueDate), st.[Group], pc.Name
ORDER BY [Calendar Year]

--page_number
select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
cr.name as [Sales Territory country],
cr.name as [Sales Territory region],
sum(soh.TotalDue) as [Sales Amount],
p.Name as [ProductName]
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode=cr.CountryRegionCode
inner join Production.Product as P on PCH.ProductID = p.ProductID
group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name,p.Name
order by [Calendar Year]select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
cr.name as [Sales Territory country],
cr.name as [Sales Territory region],
sum(soh.TotalDue) as [Sales Amount],
p.Name as [ProductName]
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode=cr.CountryRegionCode
inner join Production.Product as P on PCH.ProductID = p.ProductID
where (st.Name in(@country)) and (st.[Group] in(@Group)) and (Datepart(yyyy,soh.DueDate)) in (@year)
group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name,p.Name
order by [Calendar Year]

select distinct [Group] from Sales.SalesTerritory
select * from production.Product
select distinct DATEPART(yyyy,DueDate) as Calender_year from Sales.SalesOrderHeader

select distinct [Name] as Sales_Country from Person.CountryRegion


SELECT DISTINCT cr.Name AS Sales_Country
FROM     Person.CountryRegion as cr
join  Sales.SalesTerritory as st
on st.CountryRegionCode = cr.CountryRegionCode
WHERE  (st.[Group] IN ('Europe'))
