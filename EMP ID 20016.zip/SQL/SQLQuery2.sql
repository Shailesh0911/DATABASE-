create table emp
(
	emp_id int,
	emp_name varchar(20)
)

insert into emp(emp_id, emp_name) values (103,'JDBC')


select * from emp

SELECT * from dbo.emp

create schema kcs

select * from [Shailesh.Rajput].dbo.emp

alter table emp add mobile_no numeric(10)

alter table emp
alter column mobile_no varchar(100)

alter table emp
drop column mobile_no


select * from dbo.emp

create table tmp(
id int,name varchar(20)
)


insert into tmp values(1,'shailesh')
insert into tmp values(2,'vraj')
insert into tmp values(2,'vraj')

select * from dbo.tmp

select * from dbo.tmp 
declare @id int=1
if exists(select count(*) from dbo.tmp where id=@id having count(*) > 1)
begin
	set rowcount 1
	delete from dbo.tmp where id=@id
	set rowcount 0
	end
	select * from dbo.tmp

	-- DAY 2
drop table dbo.Employee
drop table dbo.tmp

create table depatment
( d_id int identity(1,1) primary key,
d_name varchar(20) not null
)

create table employee
(e_id int primary key identity(1,1),
e_name varchar(20) not null,
e_mail varchar(15) not null unique,
e_salary numeric(5) check(e_salary >= 10000),
e_dob date,
e_mob numeric(10) not null unique,
e_state varchar(20) default('Gujarat'),
department_id int foreign key references depatment(d_id)
)
 insert into depatment values('IT'),('HR'),('Sales'),('Finance')

 Select * from depatment


insert into employee values('abc','abc@gmail.com',15000,'12/08/2001',7405447887,'Gujarat',1)
insert into employee values('def','def@gmail.com',11000,'9/08/2001',7405447845,'Gujarat',2)
insert into employee values('ghi','ghi@gmail.com',14000,'7/21/2000',7405448787,'Gujarat',1)
insert into employee values('jkl','jkl@gmail.com',13000,'11/7/1996',7405448799,'Gujarat',2)
insert into employee values('mno','mno@gmail.com',11000,'12/08/2001',7405447884,'Gujarat',3)

--set identity_insert we can use for fixing auto increment.

set identity_insert employee on insert into employee values
('pqr','pqr@gmail.com',12500,'12/06/2001',7405447886,'Gujarat',2) 




insert into employee values('stu','stu@gmail.com',15000,'12/04/2001',7405447888,'Gujarat',4)

set identity_insert employee on 
insert into employee(e_id,e_name,e_mail,e_salary,e_dob,e_mob,e_state,department_id) values 
(10,'fdg','fdg@gmail.com',11000,'8/02/1997',7877878888,'Gujarat',1)

set identity_insert employee off
insert into employee(e_name,e_mail,e_salary,e_dob,e_mob,e_state,department_id) values 
('gdf','gdf@gmail.com',12000,'8/02/1998',7877878889,'Gujarat',1)



select * from employee
select * from depatment

-- delete from department where id = 3
delete from employee where department_id =4

--backup of table
select * into emp_bkp from employee

select * from emp_bkp

select * from emp_bkp where e_salary > 11000

--insert into emp_bkp values('sgh','sgh@gmail.com',10000,'8/05/2000',8787878444,4)
 select * from emp_bkp where e_salary between 12000 and 15000 --between satement 

 --null query

 select * from emp_bkp where department_id = null
 select * from emp_bkp where department_id = ''
 select * from emp_bkp where department_id = 'null' -- error occur we can not convert null to datatype int
 select * from emp_bkp where department_id is null -- its show null value
 select * from emp_bkp where department_id is not null -- it will all show all value because there is no null value in table

 select * from emp_bkp where department_id !=null
 select * from emp_bkp where e_name = 'abc' -- it will only show one data
 select * from emp_bkp where e_name != 'abc' -- it will show all data

 select * from emp_bkp where e_salary = 15000 and department_id=1 --it will only check condition one time
 select * from emp_bkp where e_salary = 17000 or department_id=1  --it will check two time
 select * from emp_bkp where e_salary = 17000 and department_id=1

 select * from emp_bkp where e_name in ('abc','stn')

 select * from emp_bkp where e_name ='abc' or e_name = 'def' -- it show two value its check both of condition

select * from employee
select * from depatment
 
--like query
select * from emp_bkp where e_name like '%a%'
select * from emp_bkp where e_name like '_e%'


select * from employee
select * from depatment

--join query
--join
--left join
--right join
--full join
--cross join

select e.e_name,d.d_name 
from emp_bkp e
join depatment d
on d.d_id = e.e_id

select e.e_salary,d.d_id
from emp_bkp e
join depatment d
on d.d_id = e.e_id

select e.e_name,d.d_name 
from emp_bkp e
left join depatment d
on d.d_id = e.e_id 

select e.e_name,d.* 
from emp_bkp e
left join depatment d
on d.d_id = e.e_id 

select e.*,d.* 
from emp_bkp e
right join depatment d
on d.d_id = e.e_id 


select e.*,d.* 
from emp_bkp e
full join depatment d
on d.d_id = e.e_id 

--order by query
select * from employee order by e_name desc
select * from employee order by e_name asc
select * from employee
 alter table employee add e_city varchar (20)

 update employee set e_city='Ahmedabad' where e_id=3
 
 UPDATE employee --update multipe record in one column
SET e_city = CASE WHEN e_id = 4  THEN 'Surat' 
              WHEN e_id = 5 THEN 'Ahmedabad'
              WHEN e_id = 6 THEN 'Ahmedabad'
              WHEN e_id = 7 THEN 'Rajkot'
         END
WHERE e_id IN (4,5,6,7)

select e_name,e_salary,e_mail from employee order by e_city desc

select * from employee order by 4

--top query
select top 3 * from employee order by e_salary desc -- its show top salary

WITH e_salary AS
(
SELECT *,dense_rank() OVER (ORDER BY e_salary Desc) Rnk
FROM employee
)
SELECT e_salary
FROM employee
WHERE Rnk =2

select *from employee where e_salary=(select min(e_salary) from employee)-- to found second highest salary
select *from employee where e_salary=(select max(e_salary) from employee)
--ranking funcation
--*rank,dense_rank,row_number,ntile

select *,'hello' a from employee
select * from employee

select *,rank() OVER (order by e_salary desc) from employee

select *,dense_rank() OVER (order by e_salary desc) from employee

select *,row_number() OVER (order by e_salary desc) from employee
 
select *,rank() over (partition by e_city order by e_salary asc ) from employee

--analytic function: (partition by --optional)
--lead,lag,first_value,last_value
select *, lead(e_salary) over (order by e_id) from employee -- default take only 1

select *, lead(e_salary,3) over (order by e_id) from employee

select *, lag(e_salary,3) over (order by e_id) from employee

select *, first_value(e_salary) over (order by e_id) from employee --  take first value from salary

select *, last_value(e_salary) over (order by e_gender) from employee
 
 alter table employee 
 add e_gender varchar(6)

 UPDATE employee 
SET e_gender = CASE WHEN e_id = 3 THEN 'Male' 
              WHEN e_id = 4 THEN 'Female'
              WHEN e_id = 5 THEN 'Male'
              WHEN e_id = 6 THEN 'Female'
			  WHEN e_id = 7 THEN 'Female'
         END
WHERE e_id IN (3,4,5,6,7)

select * from employee
--String Functions : ascii, char, TRIM(2017), ltrim, rtrim, lower, upper, reverse, len, 
--DATALENGTH, left,right, charindex, patindex, substring, replicate, space, replace, 
--stuff, CONCAT, QUOTENAME, CONCAT_WS(2017)

 select *, ascii(e_name) FROM employee

 select char(100) -- to know ascii value 

 select left('abc',1) -- left trim

 select right('Shailesh',5) -- right trim

 select lower('Shailesh')-- upper to lower

 select upper('shailesh') --lower to upper

 Select REVERSE('Ganesh') -- reverse side

 select CHARINDEX('l','shailesh') -- find index value

 select charindex('s','suresh',2)

 select PATINDEX('%sha%','shailesh')

 select REPLICATE('sha',3) -- replicate the value
 select stuff('sql shailesh',1,3,'Hello') -- stuff 

 select 'hello' + 'good' + 'morring'

 select 6+5
 select 'abc'+'10'  
 select '11'+'10'
 select '5'+5 -- it will add the value
 select '4r'+ 5

 select concat('abc','pqr','xyz')
 select concat('sha',5,'tyo')

select QUOTENAME('hello','(')
select QUOTENAME('hello','}'

--math funcation
select ceiling(123.45)
select ceiling(123.0)
select ceiling(125.46)-- it will take value after point 


select floor(123.5)--it will not take value after point

select floor(14.5)