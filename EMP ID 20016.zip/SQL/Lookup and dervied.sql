select * from demo
create table demoaudit1(
id int,
dname varchar(20),
Eexcutiontime datetime,
username varchar(50)
)

select * into  demo from demoaudit -- clone to table 

select * from demoaudit1

demo (id,name)
demoaudit (id,name,executiontime,uname)



emp (id,name,gender) --10 record - then add 2 record
emp (id,name,gender) --10 record


create table [Table]
(
id int identity(1,1),
[name] varchar(50),
gender varchar(10)
)
insert into [Table] values ('Shailesh','Male'),('Ganesh','Male'),('Poonam','Male'),('Pooja','Female'),
('Preet','Male'),('Prashant','Male'),('jdbc','Male')

insert into [Table] values('Arush','Male'),('Naresh','Male')

truncate table [Table1]
create table [Table1]
(
id int identity(1,1),
[name] varchar(50),
gender varchar(10)
)


select * from [Table1]